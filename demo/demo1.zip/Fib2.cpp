
// 陣列

#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    int N, fib[31];
    fib[0] = 0;
    fib[1] = 1;

    cin >> N;

    for (int i = 2; i < 31; ++i)
    {
        fib[i] = fib[i-1]+fib[i-2];
    }

    cout << fib[N] << endl;

    return 0;
}