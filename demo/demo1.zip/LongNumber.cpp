#include <iostream>
#include <string>

using namespace std;

int main(int argc, char const *argv[])
{
    string number;
    int sum;

    cin >> number;

    for (int i = 0; i < number.length(); ++i)
    {
        sum += number[i]-'0';
    }

    cout << sum << endl;

    return 0;
}
