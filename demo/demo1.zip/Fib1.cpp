
// 三個變數

#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    // f(n) = f(n-1)+f(n-2)
    int f0, f1, f2;

    int N;

    cin >> N;

    f0 = 0;
    f1 = 1;
    for (int i = 1; i < N; ++i)
    {
        f2 = f1+f0;
        f0 = f1;
        f1 = f2;
    }

    cout << f2 << endl;

    return 0;
}