#include <iostream>

using namespace std;

const char STAR = '*';
const char SPACE = ' ';

void printStar(int s);
void printSpace(int s);

int main(int argc, char const *argv[])
{
    printStar(9);
    cout << endl;

    // 上三角
    for (int i = 4, j = 1; i > 0; i--, j+=2)
    {
        printStar(i);
        printSpace(j);
        printStar(i);
        cout << endl;
    }
    // 下三角
    for (int i = 2, j = 5; i < 5; i++, j-=2)
    {
        printStar(i);
        printSpace(j);
        printStar(i);
        cout << endl;
    }
    printStar(9);
    cout << endl;

    // 上三角
    for (int i = 4, j = 1; i >= 0; i--, j+=2)
    {
        printSpace(i);
        printStar(j);
        cout << endl;
    }
    // 下三角
    for (int i = 1, j = 7; i <= 4; i++, j-=2)
    {
        printSpace(i);
        printStar(j);
        cout << endl;
    }


    return 0;
}

void printStar(int s)
{
    while(s--)
        cout << STAR;
}

void printSpace(int s)
{
    while(s--)
        cout << SPACE;
}
