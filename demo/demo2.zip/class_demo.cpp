#include <iostream>

using namespace std;

class CArray
{
private:
    int *A, size;
public:
    CArray(int s);
    ~CArray(){};
    void list();
};
CArray::CArray(int s):size(s)
{
    A = new int [size];
    for (int i = 0; i < size; ++i)
        A[i] = i+1;
}
void CArray::list()
{
    for (int i = 0; i < size; ++i)
        cout << this->A[i] << " ";
    cout << endl;
}

int main()
{
    CArray A = CArray(5);
    A.list();
    return 0;
}
