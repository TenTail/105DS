
// 遞迴

#include <iostream>

using namespace std;

int fib(int);

int main(int argc, char const *argv[])
{
    int N;
    cin >> N;
    cout << fib(N) << endl;
    return 0;
}

int fib(int f)
{
    if (f == 0)
        return 0;
    else if (f == 1)
        return 1;
    return fib(f-1)+fib(f-2);

}
