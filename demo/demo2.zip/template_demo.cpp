#include <iostream>
#include <string>

using namespace std;

template <class T>
void list(T a[], int size)
{
    for (int i = 0; i < size; ++i)
        cout << a[i] << " ";
    cout << endl;
}

int main()
{
    int a[5] = {1, 2, 3, 4, 5};
    string s[3] = {"ABC", "1234", "@#$*("};

    list(a, 5);
    list(s, 3);

    return 0;
}
