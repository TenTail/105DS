#include <iostream>
#include <string>

using namespace std;

struct student
{
    string name;
    string phone;
    int id;
};

int main()
{
    student A = {"A", "0912345678", 40044123};

    cout << A.name << endl;
    cout << A.phone << endl;
    cout << A.id << endl;

    return 0;
}
